`timescale 1ns/1ps

module tb_regfile;

    // TO FILL BY THE STUDENT

endmodule
